# # ******************** string ******************
# a = 'Single quotes'
# b = "Double quotes"
# c = '''single triple quotes'''
# d = """double triple quotes"""

# a = "don't know"
# b = 'modi says "aathmanirbhar bharat"'
# c = '''single triple quotes'''
# d = """double triple quotes"""

# pop = "Hello Sakshi... Aaj Amisha ch Dok thik zal"

# slicing
# print(pop[7])
# print(pop[-3])
# print(pop)
# print(pop[6:12])
# print(pop[-12:-3])
# print(pop[:15])
# print(pop[20:])
# print(pop[::2])
# print(pop[::-1])
# print(pop[6:12:2])

# pop = "Arithmetic operators are used to perform mathematical operations like addition, subtraction, multiplication."

# functions
# print(pop.lower())
# print(pop.upper())
# print(pop.capitalize())
# print(pop.count("o"))
# print(pop.find("to"))
# print(len(pop))
# print(pop.join("lol"))
# print(pop.split())
# print(pop.title())


# pop = "Hello Sakshi... Aaj Amisha ch Dok thik zal"
# str = "Amisha"
#
# a = len(str)
# b = pop.find(str)
#
# print("start = ",b)
# print("End = ",a+b)





# pop = "Hello Sakshi... Aaj Amisha ch Dok thik zal"
# a = pop.split()
# # for  i in range(len(a)):
# #     print(i,a[i])
# b = "Aaj"
# for i in range(len(a)):
#     if(b==a[i]):
#         print(i)

# quote = "shinning in the shade of sun like pearl upon the ocean come heal me..... oh feel me"
# print("A1)")
# print(quote[:7])
# print("A2)")
# print(quote[2:17])
# print("A3)")
# print(quote[9:])
# print("A4)")
# print(quote[-34:])
# print("A5)")
# print(quote[50])
# print("A6)")
# print(quote[::2])
# print("A7)")
# print(quote[::-4])
# print("A8)")
# print(quote[10:20:2])

# a=quote.capitalize()
# b=quote.lower()
# c=quote.upper()
# d=quote.join("AA")
# e=len(quote)
# f=quote.find("heal")
# g=quote.count("o")
# h=quote.split()
# i=quote.title()
#
# print("capitalize:")
# print(a)
# print("lower:")
# print(b)
# print("upper:")
# print(c)
# print("join:")
# print(d)
# print("length:")
# print(e)
# print("find:")
# print(f)
# print("count:")
# print(g)
# print("split:")
# print(h)
# print("title:")
# print(i)
# print("B10).")
#
# str="ocean"
# aa=len(str)
# bb=quote.find(str)
# print("begin:",bb)
# print("end:",aa+bb)
# print("\t\t\t\t\t\t\tWORDS WITH INDEX")
# cc=quote.split()
# for i in range(len(cc)):
#     print(i,cc[i])
# print("\t\t\t\t\t\t\tINPUT")
# chan=input("enter the word you wnt find the index of=")
# for i in range(len(cc)):
#     if(chan==cc[i]):
#         print(i)


 # a = pop.lower()
 # a = pop.upper()
 # a = pop.capitalize()
 # a = pop.count("Hello")
 # a = pop.find("Aaj")
 # a = len(pop)
 # a = pop.join("lol")
 # a = pop.split("a")
 # a = pop.title()

 # sentence=" Everyone have second chance called it tommorrow "
 # k= sentence.upper()



