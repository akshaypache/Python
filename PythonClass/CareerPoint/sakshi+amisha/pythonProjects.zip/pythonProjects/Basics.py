# import keyword
# print(len(keyword.kwlist))
# print(keyword.kwlist)
# print('HELLO')
# print('''hEllO''')
# print("HEllO")
# print("""hello""")
# var='universe'
# print(var)
# var='python',"spyder"
# py="""anaconda"""
# print(var)
# print(py)
# var='python',"spyder",'''anaconda''',"""developer"""
# print(var)
