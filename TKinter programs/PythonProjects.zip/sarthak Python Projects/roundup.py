# file = open("Dataset_Updated1.csv",'r')
# newf = open("new.csv",'w')
# newf.write("Super built-up  Area,availability,location,size_ BHK,society,total_sqft,bath,balcony,price")
# file.readline()
# for i in range(13320):
#     line = file.readline().replace("\n","")
#     data = line.split(",")
#     for j in range(9):
#         if(j==0):newf.write(f"{data[j]},")
#         if(j==1):newf.write(f"Ready to move,")    
#         if(j==2):newf.write(f"{data[j]},")    
#         if(j==3):newf.write(f"{data[j]},")
#         if(j==4):newf.write(f"{data[j]},")
#         if(j==5):newf.write(f"{data[j]},")
#         if(j==6):newf.write(f"{data[j]},")
#         if(j==7):newf.write(f"{data[j]},")
#         if(j==8):newf.write(f"{int(float(data[-1]))}\n")

    

# file.close()
# newf.close()