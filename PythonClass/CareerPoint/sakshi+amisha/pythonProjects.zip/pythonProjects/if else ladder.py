# if else ladder
# if(condition):
#     statements
# elif (condition):
#     statements
# elif(condition):
#     statements
# .
# .
# .
# else:
#     Statements




# a = int(input("Enter a number = "))
# if(a==1):
#     print("ONE")
# elif(a==2):
#     print("TWO")
# elif(a==3):
#     print("THREE")
# else:
#     print("wrong input")





# value = int(input("enter a number = "))
# if(value==1):
#     print("sunday")
# elif(value==2):
#     print("Monday")
# elif(value==3):
#     print("tuesday")
# else:
#     print("Wrong Input")


# i = input("enter a inventor = ")
# if("elon musk"==i):
#     print("paypal spaceX hyperloop nuiralink tesla")
# elif("steve job" ==i):
#     print("Apple")
# elif("bill gate"==i):
#     print("windows")
# elif("jeff bezos"==i):
#     print("amazon, blueorigin")
# else:
#     print("pta nhi")




# ip=input("Enter your name =")
# if(ip=="Amisha"):
#     print("Hello my name is amisha")
#     print("Contact=7654873654")
#     print("Edu.=M.sc")
# elif(ip=="Shrutika"):
#     print("Hello my name is shutika")
#     print("Contact=8765432198")
#     print("Edu.=B.sc")
# elif(ip=="Pratiksha"):
#     print("Hello my name is pratiksha")
#     print("Contact=7654398765")
#     print("Edu.=Engineering")
# else:
#     print("This person is not available")




# ip=input("enter name:")
# if(ip==exit):
#     print("Go")
# else:
#     print(ip)
#     print(input("enter ur name"))




# candidate=input("Enter your Name = ")
# if(candidate=="X"):
#     print("Hello ankita. Your Education is M.B.B.S .Contact number = 8247591837")
# elif(candidate=="Y"):
#     print("Hello sakshi. Your Education is M.sc. Contact number = 9896823985")
# elif(candidate=="Z"):
#     print("Hello amisha . Your Education is B.Arch . Contact number = 8782398569")
# else:
#     print("no match ")


