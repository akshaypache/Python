# list
# a = ["aalu", "wange","tamater","dhaniya","adrak","mirchi"]
# print(a)
# a[2] = "bhedra"
# print(a)


# list slicing
# print(a[2])
# print(a[-2])
# print(a[1:4])
# print(a[-4:-1])
# print(a[::-1])
# print(a[-4:-1][::-2])
# print(a[0][1])

# a = ["aalu", "wange","tamater","dhaniya","adrak","mirchi"]
# list function
# print(a.count("aalu"))
# a.append("lasun")
# a.pop(2)
# a.insert(3,"louki")
# a.remove("wange")
# a.sort()

# print(a)

# a = ["a","b", "chandan" , ["d", "e" , "f"]]
# print(a[3][1])


# a = [0,1,2,3,4,5,6,7,8,9,10]
# print(a[-9:-1][::-2])